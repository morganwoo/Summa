import Foundation

/// Rules for daily reflections: private journal entries attached to one day of one journey.
public enum ReflectionRule {
    public static let maxLength = 4000

    /// Trimmed, and clipped to the longest entry that is kept.
    public static func normalized(_ text: String) -> String {
        String(text.trimmingCharacters(in: .whitespacesAndNewlines).prefix(maxLength))
    }

    public static func isSavable(_ text: String) -> Bool { !normalized(text).isEmpty }
}

/// Daily reflections are part of Summa Pro. Every read and write goes through this check;
/// hiding a button is never the only thing standing in the way.
public enum ReflectionAccess {
    public enum Denial: Error, Equatable, Sendable { case proRequired }

    public static func denial(isPro: Bool) -> Denial? { isPro ? nil : .proRequired }

    /// Saved entries are never removed when a subscription ends: they are only withheld.
    public static func visible<T>(_ saved: [T], isPro: Bool) -> [T] { isPro ? saved : [] }
}

/// Fair-use limits for the reflection companion. The server enforces its own limit as well.
public enum CompanionLimit {
    public static let messagesPerDay = 30
    /// Only the most recent turns are sent, to keep requests small.
    public static let turnsSent = 16
    public static let maxMessageLength = 2000

    public static func remaining(usedToday: Int) -> Int { max(0, messagesPerDay - max(0, usedToday)) }
    public static func canSend(usedToday: Int) -> Bool { remaining(usedToday: usedToday) > 0 }
}

/// One answer from the companion. A proposed reflection is only ever a suggestion:
/// nothing is saved until the person reviews it and approves.
public struct CompanionReply: Codable, Equatable, Sendable {
    public var reply: String
    public var proposedReflection: String?

    public init(reply: String, proposedReflection: String? = nil) {
        self.reply = reply
        self.proposedReflection = proposedReflection
    }

    /// The proposal as an editable draft, or nil when there is nothing worth offering.
    public var draft: String? {
        guard let proposedReflection, ReflectionRule.isSavable(proposedReflection) else { return nil }
        return ReflectionRule.normalized(proposedReflection)
    }
}

/// Builds the made-up records used by the developer preview. Pure, so the thresholds are testable.
public enum DevScenario {
    public static let presetDays = [1, 21, 22, 66, 67, 89, 90]
    public static let presetRates = [79, 80, 100]

    /// Completed occurrences for a target rate, rounded down so 79% never reaches 80%.
    public static func completedCount(scheduled: Int, percent: Int) -> Int {
        max(0, min(scheduled, scheduled * max(0, min(100, percent)) / 100))
    }

    /// For each habit, the day offsets (0-based from the plan start) that are checked in,
    /// with misses spread evenly across the resolved days.
    public static func completedOffsets(habits: Int, resolvedDays: Int, percent: Int) -> [Set<Int>] {
        var result = Array(repeating: Set<Int>(), count: max(0, habits))
        let total = max(0, habits) * max(0, resolvedDays)
        guard total > 0 else { return result }
        let misses = total - completedCount(scheduled: total, percent: percent)
        for slot in 0..<total {
            let missed = (slot + 1) * misses / total > slot * misses / total
            if !missed { result[slot % habits].insert(slot / habits) }
        }
        return result
    }
}
